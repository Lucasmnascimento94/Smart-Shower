/*
 * defines.h
 *
 *  Created on: Jan 17, 2025
 *      Author: lucas
 */

#ifndef SRC_LIB_DEFINITIONS_DEFINES_H_
#define SRC_LIB_DEFINITIONS_DEFINES_H_



#endif /* SRC_LIB_DEFINITIONS_DEFINES_H_ */
